import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'stw-steward-client',
  template: `
    <p>
      steward-client works!
    </p>
  `,
  styles: []
})
export class StewardClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
